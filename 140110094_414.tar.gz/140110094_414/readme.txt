YEAR-Course (2015-CS101)


Team ID - 414  


SOUNDAR.S 		140110094

ANMOL RAWAT 		140110077

DIVYANSH		140040077

MOHD. BILAL SIDDIQUI	140110074


Title of the project - MINESWEEPER


Downloading code blocks:
	Code blocks is an IDE, which we have used to write and run our program. First of all we downloaded the setup of codeblocks from the link given below, http://www.codeblocks.org/downloads
Setups for various Operating Systems can be found in the above link.
We run the setup and installed codeblocks on to the ubuntu OS.


Integrating Simplecpp with codeblocks:
	We downloaded the Simplecpp package from the following link
http://www.cse.iitb.ac.in/~ranade/simplecpp/	  
This link has the simplecpp package which can be downloaded.



Instructions for installing the simplecpp package:

1. Copy this directory (simplecpp) somewhere.

2. Change the directory to this, and execute
   sh configure.sh

This should create simplecpp/lib/libsprite.a which is needed in
 simplecpp.  The include files will be in simplecpp/include.

It should also create simplecpp/s++.

s++ is the compiler for used with simplecpp. You can create an alias
so that you dont need to give the entire filename to use s++. 

To use simplecpp, your source files should contain "
#include <simplecpp>

".

  
Simplecpp directory contains following subdirectories:

    
include : contains C++ include files

       
lib     : contains libsprite.a  

       
src     : source files. 
 

       
By following the above steps Simplecpp can be integrated with Codeblocks.

The link for youtube video: http://youtu.be/HBFn0LXD-Ic